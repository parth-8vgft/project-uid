from django.shortcuts import render, redirect
from home.models import Registration
from home.forms import RegistrationForm
from django.http import HttpResponse, JsonResponse


def homePage(request):
    context = {}
    return render(request, 'home/homepage.html', context)


def sign_in(request):
    context = {}
    return render(request, 'home/login.html', context)


def register(request):
    if request.method == "POST":
        obj = RegistrationForm(request.POST)
        if obj.is_valid():
            obj.save()
        else:
            return HttpResponse('<h3>Enter Valid Values.</h3>')
    else:
        obj = RegistrationForm()
    context = {
        'data': obj,
    }
    return render(request, 'home/register.html', context)


def check(request):
    u_aadhar = request.POST['aadhar']
    u_password = request.POST['password']
    data = Registration.objects.get(aadhar=u_aadhar, password=u_password)
    context = {'data': data}
    return render(request, 'home/dashboard.html', context)


def dashboard(request):
    context = {}
    return render(request, 'home/dashboard.html', context)

def test(request):
    context = {}
    return render(request, 'home/test.html', context)