from django.db import models


class Registration(models.Model):
    gender_choices = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Others')
    )
    name = models.CharField(max_length=150)
    dob = models.DateField()
    gender = models.CharField(choices=gender_choices, max_length=15)
    contact = models.BigIntegerField()
    password = models.IntegerField()
    email = models.EmailField()
    aadhar = models.BigIntegerField()

    class Meta:
        db_table = 'registration'
