from django.shortcuts import render, redirect
from home.models import Registration
from home.forms import RegistrationForm
from django.http import HttpResponse, JsonResponse


def homePage(request):
    context = {}
    return render(request, 'home/homepage.html', context)


def sign_in(request):
    context = {}
    return render(request, 'home/login.html', context)


def register(request):
    if request.method == "POST":
        obj = RegistrationForm(request.POST)
        if obj.is_valid():
            obj.save()
        else:
            return HttpResponse('<h3>Enter Valid Values.</h3>')
    else:
        obj = RegistrationForm()
    context = {
        'data': obj,
    }
    return render(request, 'home/register.html', context)


def check(request):
    try:
        u_aadhar = request.POST['aadhar']
        u_password = request.POST['password']
        data = Registration.objects.get(aadhar=u_aadhar, password=u_password)
        context = {'data': data}

    except:
        context = dict()
        context['error'] = True
        context['errormsg'] = 'Invalid Username/ Password. Try Again.'
        return render(request, 'home/login.html', context)

    else:
        return render(request, 'home/dash3.html', context)


def dashboard(request):
    context = {}
    return render(request, 'home/dash3.html', context)


def test(request):
    context = {}
    return render(request, 'home/test.html', context)


# def edit(request):
#     data = Registration.objects.get()
#     context = {
#         'data': data,
#     }
#     return render(request, 'home/edit.html', context)


def profile(request, aadhar):
    data = Registration.objects.get(aadhar=int(aadhar))
    context = {'data': data,}
    # context = {}
    return render(request, 'home/profile.html', context)


def update(request):
    u_aadhar = request.POST['aadhar']
    obj = Registration.objects.get(aadhar=u_aadhar)
    data = RegistrationForm(request.POST, instance=obj)
    if data.is_valid():
        data.save()
        return redirect('dashboard')


def logout(request):
    return redirect('homePage')
