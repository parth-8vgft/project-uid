from django.conf.urls import url
from django.urls import path, include
from home import views
from django.contrib.auth import views as v

urlpatterns = [
    path('', views.homePage, name='homePage'),
    path('sign_in', views.sign_in, name='sign_in'),
    path('register', views.register, name='register'),
    path('check', views.check, name='check'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('test', views.test, name='test'),
    path('profile/<str:aadhar>', views.profile, name='profile'),
    # path('profile', views.profile, name='profile'),
    path('update', views.update, name='update'),
    path('logout', views.logout, name='logout'),
]
