from django.urls import path, include
from moderator import views


urlpatterns = [
    # path('', views., name=''),
]
